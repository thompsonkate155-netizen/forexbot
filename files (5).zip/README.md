# Forex News Bot

Telegram bot backend: forex headlines, a major-pairs rate snapshot, upcoming
economic events, and opt-in periodic alerts. No mini app for this one — it's
pure chat commands.

## Commands

- `/start`, `/help` — intro + command list
- `/news` — latest 5 forex headlines (title, source, link)
- `/rates` — snapshot of EUR/USD, GBP/USD, USD/JPY, USD/CHF, AUD/USD, USD/CAD, NZD/USD
- `/calendar` — upcoming economic events (impact, country, time)
- `/subscribe` / `/unsubscribe` — get fresh headlines pushed to this chat automatically

## Data sources

- **Rates** — [Frankfurter](https://www.frankfurter.app/), free, no API key, no rate limit concerns for this volume.
- **News & economic calendar** — [Finnhub](https://finnhub.io), free tier (~60 calls/min,
  personal/non-commercial use). Sign up at finnhub.io for a key — no credit card needed.
  - **Heads up on the calendar:** Finnhub has moved some previously-free endpoints behind
    paid plans before, and the economic calendar in particular may require a paid plan
    depending on your account. The bot handles this gracefully — if the endpoint rejects
    the key, `/calendar` tells the user and points them at forexfactory.com's free calendar
    instead of failing silently. Check your Finnhub dashboard to confirm what your key covers.

## Deploy to Railway

1. Push this folder to a GitHub repo.
2. In Railway: **New Project → Deploy from GitHub repo** → select the repo.
3. Add environment variables under **Variables**:
   - `BOT_TOKEN` — from @BotFather
   - `FINNHUB_API_KEY` — from finnhub.io (needed for `/news` and `/calendar`; `/rates` works without it)
   - `NOTIFY_INTERVAL_MINUTES` — optional, default `240` (every 4 hours)
   - `DATA_DIR` — optional, see persistence note below
4. Deploy. Check **Deploy Logs** for "Forex News Bot is up and polling for updates."

### Persisting subscribers across redeploys (optional but recommended)

The bot stores its subscriber list and last-seen-news-id in a small `state.json`
file on disk. Railway's local filesystem is wiped on every redeploy, so by
default your subscriber list would reset each time you ship a change. To avoid
that:

1. In Railway, add a **Volume** to this service (Settings → Volumes), mounted at e.g. `/data`.
2. Set `DATA_DIR=/data` in your environment variables.

If you skip this, the bot still works fine — subscribers just need to
`/subscribe` again after a redeploy.

## Get a bot token (if you don't have one yet)

1. Open **@BotFather** on Telegram → `/newbot` → follow the prompts, copy the token.
2. Optional: `/setdescription` in BotFather to set the bot's public description
   to match the copy you shared (the ⚡️📈🌍🔔 one).

## Notes

- Long-polling (`bot.launch()`), not webhooks — simplest on Railway, fine at this scale.
- The tiny HTTP server on `$PORT` is just so Railway has a health-check target; it's
  not required for the bot's actual logic.
- `checkAndNotify` runs on a plain `setInterval`, not a cron library — no extra
  dependency, and "every N minutes for as long as the process is alive" is all
  this needs.
